module.exports = function (a, b) {
  return 0;
};
